
// * Warm up 
// * Who wants to explain the function below?
// function addNums(num1, num2) {
//     // ? Explain the difference between console.log and return
//     console.log(num1 + num2);
//     return num1 + num2;
// }
// var result = addNums(4,5) // 9

// ? Write a function that takes a name and returns a greeting 
// * ex: calling the function greeting("Juli") should return => "Hello, Juli! Welcome to the dojo!"
// function greeting(name){
//     return `Hello ${name}! Welcome to the dojo ${2+2}`
// }

// var result = greeting('Juli')
// console.log(result);

// ? Write a function that takes in two numbers and returns true if the first number is larger than the second number. Otherwise, it should return false.
// function whichNumIsLarger(num1, num2){
//     if(num1 > num2){
//         return true
//     }else{
//         return false
//     }
// }
// var result = whichNumIsLarger(5,4)
// // OR
// console.log(whichNumIsLarger(5,14));

// ? Write a function that takes in a number and returns true if the number is odd, otherwise it should return false.


// ? Write a function that counts from 0 to 10 and console.logs each number in the count.


// ? Write a function that counts down from 100 to 0 and console.logs each number in the countdown. Bonus: Once the countdown is over it should console.log("Blast off!")


// ? Loop through an array. Write a function that takes in an array and console.logs each value in the array from beginning to end 


// ? Write a function that takes in an array of numbers and console.logs the sum of the first value in the array and the last value in the array.


// ? Write a function that takes in an array of numbers and returns the sum of all the numbers in the array.



// ? Write a function that takes in a number and returns an array of integers from n to 1 where n is greater than 0
// * Example: returnArrOfNums(5) should return => [5,4,3,2,1]